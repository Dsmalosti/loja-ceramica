import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    // Quando o Flask do Diogo estiver rodando, o front chama /api/... e o Vite repassa pro Flask.
    // Sem CORS no dev, mesma URL relativa em produção.
    proxy: {
      '/api': 'http://127.0.0.1:5000',
    },
  },
})
