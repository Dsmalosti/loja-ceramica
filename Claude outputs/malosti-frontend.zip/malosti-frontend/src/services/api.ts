import type { Category, Course, Product } from '../types'
import { categories, courses, products } from './mockData'

/*
 * CAMADA DE SERVIÇO — o resto do app só conversa com estas funções.
 * Hoje elas devolvem o mock; amanhã fazem fetch no Flask.
 * Nenhum componente precisa mudar quando a troca acontecer.
 */

const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false'
const API_URL = import.meta.env.VITE_API_URL ?? '/api'

// Simula latência de rede pra gente já desenhar os estados de loading
const delay = <T,>(data: T, ms = 300) =>
  new Promise<T>((resolve) => setTimeout(() => resolve(structuredClone(data)), ms))

async function http<T>(path: string): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, { credentials: 'include' })
  if (!res.ok) throw new Error(`Erro ${res.status} em ${path}`)
  return res.json() as Promise<T>
}

export const api = {
  getCategories: (): Promise<Category[]> =>
    USE_MOCK ? delay(categories) : http('/categories'),

  getProducts: (): Promise<Product[]> =>
    USE_MOCK ? delay(products.filter((p) => p.is_active)) : http('/products'),

  getFeaturedProducts: (limit = 3): Promise<Product[]> =>
    USE_MOCK
      ? delay(products.filter((p) => p.is_active && p.is_featured).slice(0, limit))
      : http(`/products?featured=1&limit=${limit}`),

  getCourses: (): Promise<Course[]> =>
    USE_MOCK ? delay(courses.filter((c) => c.is_active)) : http('/courses'),
}
