import type { Category, Course, Product } from '../types'

/*
 * DADOS FICTÍCIOS — espelham o JSON que a API do Flask vai devolver.
 * Somem quando a api.ts passar a chamar o backend de verdade.
 */

// Placeholder com as cores da marca. Trocar pelas fotos reais da Julia.
const img = (label: string, bg = 'F1E9DC', fg = '5B4632') =>
  `https://placehold.co/800x1000/${bg}/${fg}?font=playfair-display&text=${encodeURIComponent(label)}`

export const categories: Category[] = [
  { id: 1, name: 'Utilitários', slug: 'utilitarios' },
  { id: 2, name: 'Tinta corante', slug: 'tinta-corante' },
  { id: 3, name: 'Carimbo', slug: 'carimbo' },
]

export const products: Product[] = [
  {
    id: 1,
    name: 'Caneca Terra',
    slug: 'caneca-terra',
    description: 'Caneca torneada à mão em grés, esmalte acetinado em tom areia. Capacidade aprox. 300 ml.',
    price: 89.9,
    promo_price: null,
    stock: 12,
    category_id: 1,
    images: [img('Caneca Terra')],
    is_featured: true,
    is_active: true,
  },
  {
    id: 2,
    name: 'Bowl Âmbar',
    slug: 'bowl-ambar',
    description: 'Bowl médio com esmalte âmbar escorrido. Ideal para saladas, caldos e frutas. Ø 15 cm.',
    price: 119.0,
    promo_price: 99.0,
    stock: 6,
    category_id: 1,
    images: [img('Bowl Âmbar', 'F4D9A0')],
    is_featured: true,
    is_active: true,
  },
  {
    id: 3,
    name: 'Prato Raso Mocha',
    slug: 'prato-raso-mocha',
    description: 'Prato raso de 26 cm com borda irregular e acabamento mocha fosco. Peça única.',
    price: 149.0,
    promo_price: null,
    stock: 4,
    category_id: 1,
    images: [img('Prato Mocha', '5B4632', 'F4D9A0')],
    is_featured: true,
    is_active: true,
  },
  {
    id: 4,
    name: 'Tinta Corante Champanhe',
    slug: 'tinta-corante-champanhe',
    description: 'Corante cerâmico em pó, 100 g, para engobes e esmaltes. Rende tons quentes após a queima.',
    price: 39.9,
    promo_price: null,
    stock: 30,
    category_id: 2,
    images: [img('Tinta Corante')],
    is_featured: false,
    is_active: true,
  },
  {
    id: 5,
    name: 'Carimbo Folhagem',
    slug: 'carimbo-folhagem',
    description: 'Carimbo para texturizar argila, motivo folhagem. Base em madeira, 5 × 5 cm.',
    price: 49.9,
    promo_price: 42.0,
    stock: 15,
    category_id: 3,
    images: [img('Carimbo')],
    is_featured: false,
    is_active: true,
  },
]

export const courses: Course[] = [
  {
    id: 1,
    title: 'Introdução à Modelagem Manual',
    slug: 'introducao-modelagem-manual',
    description: 'Aprenda as técnicas de beliscão, acordelado e placas e saia com suas primeiras peças.',
    price: 380.0,
    promo_price: null,
    duration: '4 encontros de 2h30',
    schedule: 'Sábados, 9h às 11h30',
    spots: 8,
    image: img('Modelagem', 'E6DCCB'),
    signup_url: 'https://forms.gle/exemplo-modelagem',
    is_active: true,
  },
  {
    id: 2,
    title: 'Torno para Iniciantes',
    slug: 'torno-iniciantes',
    description: 'Centralização, abertura e levantamento de paredes no torno elétrico, com acompanhamento individual.',
    price: 520.0,
    promo_price: 470.0,
    duration: '6 encontros de 2h',
    schedule: 'Quartas, 19h às 21h',
    spots: 5,
    image: img('Torno', 'C8792C', 'FAF6EF'),
    signup_url: 'https://forms.gle/exemplo-torno',
    is_active: true,
  },
]
