import { useEffect, useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import logo from '../../assets/logo.jpeg'
import { NAV_LINKS, SITE } from '../../config/site'

const linkClass = ({ isActive }: { isActive: boolean }) =>
  [
    'relative py-1 text-sm tracking-wide transition-colors',
    'after:absolute after:inset-x-0 after:-bottom-0.5 after:h-px after:origin-left after:bg-amber after:transition-transform',
    isActive
      ? 'text-mocha after:scale-x-100'
      : 'text-stone hover:text-mocha after:scale-x-0 hover:after:scale-x-100',
  ].join(' ')

export function Navbar() {
  const [open, setOpen] = useState(false)
  // Trava o scroll do fundo e permite fechar com Esc enquanto o menu está aberto
  useEffect(() => {
    if (!open) return
    document.body.style.overflow = 'hidden'
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [open])

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-linen/70 bg-cream/90 backdrop-blur">
        <nav className="mx-auto flex h-20 max-w-6xl items-center justify-between px-5 md:px-8">
          <Link to="/" aria-label={`${SITE.name} — página inicial`} className="shrink-0">
            {/* mix-blend-multiply: o fundo branco do JPG "some" sobre o off-white */}
            <img
              src={logo}
              alt={`${SITE.name} ${SITE.tagline}`}
              className="h-12 w-auto mix-blend-multiply md:h-14"
            />
          </Link>

          <ul className="hidden items-center gap-8 md:flex">
            {NAV_LINKS.map((l) => (
              <li key={l.to}>
                <NavLink to={l.to} end={l.to === '/'} className={linkClass}>
                  {l.label}
                </NavLink>
              </li>
            ))}
          </ul>

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? 'Fechar menu' : 'Abrir menu'}
            className="-mr-2 flex h-11 w-11 items-center justify-center rounded-full text-mocha md:hidden"
          >
            <span className="relative block h-3.5 w-6">
              <span
                className={`absolute left-0 h-px w-6 bg-current transition-all ${open ? 'top-1.5 rotate-45' : 'top-0'}`}
              />
              <span
                className={`absolute left-0 top-1.5 h-px w-6 bg-current transition-opacity ${open ? 'opacity-0' : ''}`}
              />
              <span
                className={`absolute left-0 h-px w-6 bg-current transition-all ${open ? 'top-1.5 -rotate-45' : 'top-3'}`}
              />
            </span>
          </button>
        </nav>
      </header>

      {/* Menu mobile: FORA do <header>. O backdrop-blur do header cria um novo
          "containing block" e quebraria o position:fixed deste painel. */}
      <div
        id="mobile-menu"
        className={`fixed inset-x-0 top-20 bottom-0 z-30 bg-cream transition-all duration-300 md:hidden ${
          open ? 'visible opacity-100' : 'invisible -translate-y-2 opacity-0'
        }`}
      >
        <ul className="flex flex-col px-5 pt-6">
          {NAV_LINKS.map((l) => (
            <li key={l.to} className="border-b border-linen">
              <NavLink
                to={l.to}
                end={l.to === '/'}
                onClick={() => setOpen(false)} // fecha no próprio clique, sem effect extra
                className={({ isActive }) =>
                  `block py-4 font-serif text-2xl ${isActive ? 'text-amber' : 'text-mocha'}`
                }
              >
                {l.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </div>
    </>
  )
}
