import { Link } from 'react-router-dom'
import { NAV_LINKS, SITE } from '../../config/site'
import { whatsappLink } from '../../utils/format'

// Calculado uma vez quando o módulo carrega, não a cada render
const YEAR = new Date().getFullYear()

export function Footer() {
  return (
    <footer className="bg-mocha text-cream/80">
      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 md:grid-cols-3 md:px-8">
        <div>
          <p className="font-serif text-3xl italic text-cream">{SITE.name}</p>
          <p className="mt-1 text-xs uppercase tracking-[0.3em] text-champagne">{SITE.tagline}</p>
          <p className="mt-6 max-w-xs text-sm leading-relaxed">
            Peças utilitárias feitas à mão, uma a uma, para fazer parte do seu dia a dia.
          </p>
        </div>

        <div>
          <h2 className="text-sm uppercase tracking-[0.2em] text-champagne font-sans">Navegação</h2>
          <ul className="mt-5 grid grid-cols-2 gap-y-2 text-sm">
            {NAV_LINKS.map((l) => (
              <li key={l.to}>
                <Link to={l.to} className="hover:text-champagne">{l.label}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="text-sm uppercase tracking-[0.2em] text-champagne font-sans">Contato</h2>
          <ul className="mt-5 space-y-3 text-sm">
            <li>
              <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="hover:text-champagne">
                WhatsApp · {SITE.whatsappDisplay}
              </a>
            </li>
            <li>
              <a href={SITE.instagramUrl} target="_blank" rel="noopener noreferrer" className="hover:text-champagne">
                Instagram · @{SITE.instagram}
              </a>
            </li>
            <li>
              <a href={SITE.mapsUrl} target="_blank" rel="noopener noreferrer" className="hover:text-champagne">
                {SITE.address}
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-cream/10">
        <p className="mx-auto max-w-6xl px-5 py-6 text-xs text-cream/50 md:px-8">
          © {YEAR} {SITE.name} {SITE.tagline}. Todos os direitos reservados.
        </p>
      </div>
    </footer>
  )
}
