import { Link } from 'react-router-dom'
import type { Product } from '../../types'
import { formatPrice } from '../../utils/format'

export function ProductCard({ product }: { product: Product }) {
  const onSale = product.promo_price !== null && product.promo_price < product.price
  const soldOut = product.stock <= 0

  return (
    <Link to={`/loja/${product.slug}`} className="group block">
      <div className="relative aspect-[4/5] overflow-hidden bg-sand">
        <img
          src={product.images[0]}
          alt={product.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {onSale && !soldOut && (
          <span className="absolute top-3 left-3 bg-amber px-2.5 py-1 text-[11px] font-medium uppercase tracking-wider text-cream">
            Promoção
          </span>
        )}
        {soldOut && (
          <span className="absolute top-3 left-3 bg-mocha px-2.5 py-1 text-[11px] font-medium uppercase tracking-wider text-cream">
            Esgotado
          </span>
        )}
      </div>

      <div className="mt-4 text-center">
        <h3 className="font-serif text-xl text-mocha group-hover:text-amber transition-colors">{product.name}</h3>
        <p className="mt-1 text-sm">
          {onSale ? (
            <>
              <span className="mr-2 text-stone line-through">{formatPrice(product.price)}</span>
              <span className="font-medium text-amber">{formatPrice(product.promo_price!)}</span>
            </>
          ) : (
            <span className="text-stone">{formatPrice(product.price)}</span>
          )}
        </p>
      </div>
    </Link>
  )
}

export function ProductCardSkeleton() {
  return (
    <div className="animate-pulse">
      <div className="aspect-[4/5] bg-sand" />
      <div className="mx-auto mt-4 h-5 w-2/3 bg-sand" />
      <div className="mx-auto mt-2 h-4 w-1/3 bg-sand" />
    </div>
  )
}
