// Dados fixos da empresa. Um único lugar pra trocar se mudar.
export const SITE = {
  name: 'Julia Malosti',
  tagline: 'Arte Cerâmica',
  whatsapp: '5512991399090', // formato internacional, só dígitos (exigido pelo wa.me)
  whatsappDisplay: '+55 12 99139-9090',
  instagram: 'malosti.loja',
  instagramUrl: 'https://www.instagram.com/malosti.loja',
  address: 'Rua Espanha, 532 - Jardim das Nações',
  mapsUrl: 'https://www.google.com/maps/search/?api=1&query=Rua+Espanha+532+Jardim+das+Na%C3%A7%C3%B5es',
} as const

export const NAV_LINKS = [
  { to: '/', label: 'Home' },
  { to: '/loja', label: 'Loja' },
  { to: '/cursos', label: 'Cursos' },
  { to: '/servicos', label: 'Serviços' },
  { to: '/sobre', label: 'Sobre' },
  { to: '/contato', label: 'Contato' },
] as const
