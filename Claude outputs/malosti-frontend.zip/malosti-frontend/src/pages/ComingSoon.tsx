// Página provisória pras rotas que ainda vamos construir (evita link quebrado na demo)
export function ComingSoon({ title }: { title: string }) {
  return (
    <section className="mx-auto max-w-6xl px-5 py-32 text-center md:px-8">
      <h1 className="text-5xl">{title}</h1>
      <p className="mt-4 text-stone">Página em construção.</p>
    </section>
  )
}
