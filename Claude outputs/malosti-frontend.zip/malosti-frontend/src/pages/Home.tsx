import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ProductCard, ProductCardSkeleton } from '../components/product/ProductCard'
import { api } from '../services/api'
import type { Product } from '../types'
import { whatsappLink } from '../utils/format'

function Hero() {
  return (
    <section className="relative overflow-hidden bg-sand">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-20 md:grid-cols-2 md:px-8 md:py-28">
        <div>
          <p className="text-xs uppercase tracking-[0.35em] text-amber">Feito à mão em pequenas tiragens</p>
          {/* SLOGAN: aguardando a Julia. Texto provisório. */}
          <h1 className="mt-5 text-5xl leading-[1.05] md:text-6xl lg:text-7xl">
            Cerâmica para <em className="text-amber">viver</em> o dia a dia
          </h1>
          <p className="mt-6 max-w-md leading-relaxed text-stone">
            Peças utilitárias criadas no ateliê, pensadas para irem da mesa à cozinha e ganharem
            história com o uso.
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <Link
              to="/loja"
              className="bg-mocha px-8 py-3.5 text-sm tracking-wide text-cream transition-colors hover:bg-amber"
            >
              Conhecer a loja
            </Link>
            <Link
              to="/cursos"
              className="border border-mocha px-8 py-3.5 text-sm tracking-wide text-mocha transition-colors hover:bg-mocha hover:text-cream"
            >
              Ver cursos
            </Link>
          </div>
        </div>

        {/* Composição decorativa até chegarem as fotos do ateliê */}
        <div className="relative mx-auto aspect-square w-full max-w-md" aria-hidden="true">
          <div className="absolute inset-[8%] rounded-full bg-champagne" />
          <div className="absolute bottom-0 left-[18%] h-[72%] w-[64%] rounded-t-full bg-mocha" />
          <div className="absolute bottom-[10%] left-[34%] h-[38%] w-[32%] rounded-t-full bg-amber/90" />
          <div className="absolute inset-x-0 bottom-0 h-px bg-mocha/30" />
        </div>
      </div>
    </section>
  )
}

function Featured() {
  const [products, setProducts] = useState<Product[] | null>(null)
  const [error, setError] = useState(false)

  useEffect(() => {
    let active = true // evita setState se o componente desmontar antes da resposta
    api
      .getFeaturedProducts(3)
      .then((data) => active && setProducts(data))
      .catch(() => active && setError(true))
    return () => {
      active = false
    }
  }, [])

  return (
    <section className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-28">
      <div className="mb-12 flex items-end justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.35em] text-amber">Seleção do ateliê</p>
          <h2 className="mt-3 text-4xl md:text-5xl">Destaques</h2>
        </div>
        <Link to="/loja" className="shrink-0 text-sm text-mocha underline-offset-4 hover:underline">
          Ver todas →
        </Link>
      </div>

      {error ? (
        <p className="text-stone">Não foi possível carregar os produtos agora. Tente novamente em instantes.</p>
      ) : (
        <div className="grid gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
          {products
            ? products.map((p) => <ProductCard key={p.id} product={p} />)
            : Array.from({ length: 3 }, (_, i) => <ProductCardSkeleton key={i} />)}
        </div>
      )}
    </section>
  )
}

function CustomPieces() {
  return (
    <section className="bg-champagne/40">
      <div className="mx-auto flex max-w-6xl flex-col items-start gap-6 px-5 py-16 md:flex-row md:items-center md:justify-between md:px-8">
        <div>
          <h2 className="text-3xl md:text-4xl">Quer uma peça só sua?</h2>
          <p className="mt-2 max-w-lg text-stone">
            Jogos de mesa, presentes e encomendas personalizadas. Conte sua ideia direto pra Julia.
          </p>
        </div>
        <a
          href={whatsappLink('Olá, Julia! Gostaria de encomendar uma peça personalizada.')}
          target="_blank"
          rel="noopener noreferrer"
          className="shrink-0 bg-amber px-8 py-3.5 text-sm tracking-wide text-cream transition-colors hover:bg-amber-dark"
        >
          Pedir peça personalizada
        </a>
      </div>
    </section>
  )
}

export function Home() {
  return (
    <>
      <Hero />
      <Featured />
      <CustomPieces />
    </>
  )
}
