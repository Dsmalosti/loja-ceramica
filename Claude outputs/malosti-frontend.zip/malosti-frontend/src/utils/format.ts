import { SITE } from '../config/site'

const brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' })

export const formatPrice = (value: number) => brl.format(value)

// Gera link do WhatsApp com mensagem pré-preenchida (já com encode de acentos e espaços)
export const whatsappLink = (message = 'Olá, Julia! Vim pelo site.') =>
  `https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(message)}`
