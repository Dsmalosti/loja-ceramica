import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { Layout } from './components/layout/Layout'
import { ComingSoon } from './pages/ComingSoon'
import { Home } from './pages/Home'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="loja" element={<ComingSoon title="Loja" />} />
          <Route path="loja/:slug" element={<ComingSoon title="Produto" />} />
          <Route path="cursos" element={<ComingSoon title="Cursos" />} />
          <Route path="servicos" element={<ComingSoon title="Serviços" />} />
          <Route path="sobre" element={<ComingSoon title="Sobre" />} />
          <Route path="contato" element={<ComingSoon title="Contato" />} />
          <Route path="*" element={<ComingSoon title="Página não encontrada" />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
