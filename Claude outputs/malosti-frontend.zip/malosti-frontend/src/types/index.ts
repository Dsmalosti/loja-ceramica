/*
 * Contratos de dados = o "acordo" entre o front e a API do Flask.
 * Campos em snake_case de propósito: é assim que o Python serializa por padrão.
 * Se o Diogo mudar algo no model, o TypeScript acusa o erro aqui no front.
 */

export interface Category {
  id: number
  name: string
  slug: string
}

export interface Product {
  id: number
  name: string
  slug: string
  description: string
  price: number
  promo_price: number | null // preço com desconto (CRUD de Promoções)
  stock: number
  category_id: number
  images: string[]
  is_featured: boolean // aparece em "Destaques" na Home
  is_active: boolean
}

export interface Course {
  id: number
  title: string
  slug: string
  description: string
  price: number
  promo_price: number | null
  duration: string
  schedule: string
  spots: number
  image: string
  signup_url: string // link externo (Google Forms)
  is_active: boolean
}
